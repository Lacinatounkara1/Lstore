# Mon APK Store (PWA)

Fichiers : index.html, manifest.webmanifest, sw.js, icon-192.png, icon-512.png

## Mettre en ligne gratuitement (au choix)
- Netlify Drop : va sur app.netlify.com/drop et glisse ce dossier. Tu obtiens un lien https tout de suite.
- Cloudflare Pages : « Create project » > « Upload assets » > dépose le dossier.
- GitHub Pages : crée un dépôt, envoie les fichiers, puis Settings > Pages > branche main.

## Installer sur le téléphone
Ouvre le lien https dans Chrome (Android) > menu ⋮ > « Installer l’application ».
L’app s’ouvre alors en plein écran, avec son icône, et fonctionne hors ligne.
(La PWA ne marche qu’en https, pas en ouvrant le fichier directement.)
